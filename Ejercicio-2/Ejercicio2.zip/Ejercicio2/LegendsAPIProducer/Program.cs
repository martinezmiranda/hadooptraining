﻿namespace LegendsAPIProducer
{
    using Microsoft.ServiceBus.Messaging;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using RiotApi.Net.RestClient;
    using RiotApi.Net.RestClient.Configuration;

    public class Program
    {
        // Obtener nuestra clave personal registrandonos en https://developer.riotgames.com/sign-in
        static string API_KEY = "OUR_API_KEY";

        static void Main(string[] args)
        {
            var tokenSource = new CancellationTokenSource();

            var task = new TaskFactory()
                .StartNew(() => Produce(tokenSource.Token));

            Console.WriteLine("Connecting to the League of Legends API and transmitting data to Event Hub");
            Console.WriteLine("Press any key to stop");
            Console.ReadLine();

            tokenSource.Cancel();
            task.Wait();
        }

        static void Produce(CancellationToken cancellationToken)
        {
            var hub = EventHubClient.Create("bigdataeventhubdemo");
            var riotClient = new RiotClient(API_KEY);

            var summonerName = "zet4en3ka";
            var summoner = riotClient.Summoner.GetSummonersByName(RiotApiConfig.Regions.EUW, summonerName).FirstOrDefault();
            var summonerID = 0L;

            if (summoner.Value == null)
            {
                Console.WriteLine("Unable to fetch matches");
                Console.WriteLine("The application will close after you press any key");
                Console.ReadLine();
            }
            else
            {
                summonerID = summoner.Value.Id;
                Console.WriteLine("Monitoring games for summoner with ID {0}", summonerID);
            }
            
            var matches = riotClient.MatchList.GetMatchListBySummonerId(RiotApiConfig.Regions.EUW, summonerID).Matches.GetEnumerator();

            while (matches.MoveNext())
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return;
                }

                var currentMatchID = matches.Current.MatchId;
                var currentGameStatus = riotClient.Match.GetMatchById(RiotApiConfig.Regions.EUW, currentMatchID, true);

                var summonerParticipantID = currentGameStatus.ParticipantIdentities.Where(p => p.Player.SummonerId == summonerID).Select(p => p.ParticipantId).FirstOrDefault();
                var summonerParticipant = currentGameStatus.Participants.Where(p => p.ParticipantId == summonerParticipantID).FirstOrDefault();
                var summonerTeamID = summonerParticipant.TeamId;

                var frames = currentGameStatus.Timeline.Frames.ToArray();

                for (int i = 0; i < frames.Length; i++)
                {

                    var gameData = new GameData();
                    gameData.MatchID = currentMatchID;
                    gameData.TimeStamp = UnixTimeStampToDateTime(currentGameStatus.MatchCreation + frames[i].Timestamp);
                    gameData.SummonerChampionID = summonerParticipant.ChampionId;
                    var summonerTeamMembers = currentGameStatus.Participants.Where(p => p.TeamId == summonerTeamID).Select(p => p.ParticipantId).ToList();
             
                    foreach (var player in frames[i].ParticipantFrames.Values)
                    {
                        if (summonerTeamMembers.Contains(player.ParticipantId))
                        {
                            gameData.SummonersTeamGold += player.TotalGold;
                        }
                        else
                        {
                            gameData.OtherTeamGold += player.TotalGold;
                        }
                    }

                    Console.WriteLine("MatchID {0}. Summoner Team Gold: {1}. Other Team Gold: {2}", gameData.MatchID, gameData.SummonersTeamGold, gameData.OtherTeamGold);

                    hub.SendAsync(new EventData(
                        UTF8Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(gameData)))).Wait();

                    Thread.Sleep(10000);
                }

                var result = currentGameStatus.Teams.Where(t => t.TeamId == summonerTeamID).FirstOrDefault().Winner ? "WON" : "LOST";
                Console.WriteLine("At the end of the match {0} the Summoner Team {1}", currentMatchID, result);
            }
        }

        public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddMilliseconds(unixTimeStamp).ToLocalTime();
            return dtDateTime;
        }
    }
}
