﻿namespace LegendsAPIProducer
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    
    public class GameData
    {
        public long MatchID { get; set; }
        public DateTime TimeStamp { get; set; }
        public int SummonerChampionID { get; set; }
        public long SummonersTeamGold { get; set; }
        public long OtherTeamGold { get; set; }
    }
}
